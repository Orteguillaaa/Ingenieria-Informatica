#include <iostream>
#include "Torneo.h"
#include"Comun.h"
#include <fstream>
#include <cstring>
#include"Clasificacion.h"

using namespace std;

int main()
{
    Torneo tor;
    TorneoAux tabla[N], torneoActual;
    int elec, nTorneos, elecTorneos,general;
    cadena copiar;
    fstream fichTorneo;
    bool valido=false;
    Golfista pasar;
    fichTorneo.open("TORNEOS.dat", ios::binary|ios::in|ios::out);
    if(!fichTorneo){
        cout<<"Error al abrir el fichero";
    }
    fichTorneo.seekg(0, ios::end);
    nTorneos=(fichTorneo.tellg())/(sizeof(TorneoAux));
    cout<<"Bienvenido:\n\n";
    do{
        fichTorneo.seekg(0, ios::beg);
        for(int i=0;i<nTorneos;i++){
            fichTorneo.read((char*) &tabla[i], sizeof(TorneoAux));
        }
        cout<<"Club de golf\n--------------------------------\nNumero de torneos: "<<nTorneos<<"\n\n1) Listado de Torneos Abiertos\n2) Alta Torneo\n3) Elegir Torneo\n4) Salir\n\Indique la opcion deseada :\n";
        cin>>elec;
        cout<<endl;
        switch (elec){
            case 1:{
                for(int i=0;i<nTorneos;i++){
                    cout<<"Numero de golfistas: "<<tabla[i].nGolfistas<<endl;
                    cout<<"Nombre torneo: "<<tabla[i].nTorneo<<endl;
                    cout<<"Nombre fichero: "<<tabla[i].nFichero<<endl<<endl;
                }
                break;}
            case 2:{
                    if(nTorneos<N){
                    cout<<"Nombre torneo: ";
                    cin>>copiar;
                    strcpy(tabla[nTorneos+1].nTorneo, copiar);
                    cout<<"Nombre fichero: ";
                    cin>>copiar;
                    strcpy(tabla[nTorneos+1].nFichero, copiar);
                    tabla[nTorneos+1].nGolfistas=0;
                    fichTorneo.seekg(nTorneos * sizeof(TorneoAux), ios::beg);
                    fichTorneo.write((char*) &tabla[nTorneos+1], sizeof(TorneoAux));
                    nTorneos++;
                    }
                    else{cout<<"No se pueden anhadir mas\n\n";}
                break;}
            case 3:{
                valido=false;
                do{
                    cout<<"Numero del torneo: ";
                    cin>>elecTorneos;
                    cout<<endl<<endl;
                    if(elecTorneos<=nTorneos&&elecTorneos>0){
                        valido=true;
                        elecTorneos--;
                        torneoActual=tabla[elecTorneos];}
                    else{
                        cout<<"Torneo no valido\n\n";
                }}while(!valido);
                tor.crearFichero(torneoActual.nFichero);
                tor.putNomFichero(torneoActual.nFichero);
                tor.putNomTorneo(torneoActual.nTorneo);
                tor.putNumGolfistas(torneoActual.nGolfistas);
                do{
                    cout << "Torneo "<<torneoActual.nTorneo << endl;
                    cout << "--------------------------------------------" << endl;
                    cout << "Golfistas: " << torneoActual.nGolfistas << endl << endl;
                    cout << "1) Consulta de inscripciones" << endl;
                    cout << "2) Inscripcion al torneo" << endl;
                    cout << "3) Busqueda de una inscripcion" << endl;
                    cout << "4) Modificar datos de una inscripcion" << endl;
                    cout << "5) Eliminar una inscripcion" << endl;
                    cout << "6) Mostrar Resultados del Torneo" << endl;
                    cout << "7) Salir" << endl << endl;
                    cin>>elecTorneos;
                    switch (elecTorneos){
                        case 1:{
                            cout<<"Ponga handicap: ";
                            cin>>general;
                            cout<<"\n\n";
                            tor.mostrar(general);
                            break;
                        }
                        case 2:{
                            cout<<"Licencia: ";
                            do{
                                cin>>pasar.licencia;
                                general=tor.buscar(pasar.licencia);
                                if(general!=-1){
                                    cout<<"\n\nError, dos licencias iguales, introduzca otra licencia: ";
                                }
                            }while(general!=-1);
                            cout<<"\n\nHandicap: ";
                            cin>>pasar.handicap;
                            cout<<"\n\nNombre: ";
                            cin>>pasar.nombre;
                            cout<<"\n\nApellido: ";
                            cin>>pasar.apellidos;
                            pasar.golpes=0;
                            pasar.resultado=0;
                            tor.insertar(pasar);
                            cout<<"\n\n";
                            break;
                        }
                        case 3:{
                            cout<<"Licencia: ";
                            cin>>copiar;
                            general=tor.buscar(copiar);
                            if(general==-1){
                                cout<<"\n\nError, no existe el golfista en cuestion\n\n";
                            }
                            else{
                                cout<<"\n\n";
                                tor.consultar(general);
                                cout<<"\n\n";
                            }
                            break;
                        }
                        case 4:{
                            cout<<"Licencia: ";
                            cin>>pasar.licencia;
                            general=tor.buscar(pasar.licencia);
                            if(general==-1){
                                cout<<"\n\nError, no existe el golfista en cuestion\n\n";
                            }
                            else{
                            cout<<"\n\nNombre: ";
                            cin>>pasar.nombre;
                            cout<<"\n\nApellido: ";
                            cin>>pasar.apellidos;
                            pasar.golpes=0;
                            pasar.resultado=0;
                            pasar.handicap=0;
                            tor.modificar(pasar, general);
                            }
                            break;
                        }
                        case 5:{
                            cout<<"Licencia: ";
                            cin>>copiar;
                            general=tor.buscar(copiar);
                            if(general==-1){
                                cout<<"\n\nError, no existe el golfista en cuestion\n\n";
                            }
                            tor.eliminar(general);
                            break;
                        }
                        case 6:{

                        }
                        case 7:{
                            tor.Cerrar();
                            break;
                        }
                        default:{
                            cout<<"Opcion no valida\n\n";
                            break;}
                    }
                }while(elecTorneos!=7);
                break;}
            case 4:{
                cout<<"Adios";
                break;}
            default:{
                cout<<"Opcion no valida\n\n";
                break;}
        }
    }while(elec!=4);
    fichTorneo.close();
    return 0;
}
