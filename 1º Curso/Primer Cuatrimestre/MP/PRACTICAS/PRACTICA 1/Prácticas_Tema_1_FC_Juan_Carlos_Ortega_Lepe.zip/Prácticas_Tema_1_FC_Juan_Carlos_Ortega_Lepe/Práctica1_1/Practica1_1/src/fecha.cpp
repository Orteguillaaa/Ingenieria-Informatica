#include "Fecha.h"
#include <iomanip>

// Funci�n auxiliar para verificar si un a�o es bisiesto
bool Fecha::esBisiesto(int year) const {
    return (year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0));
}

// Funci�n auxiliar para obtener el n�mero de d�as en un mes
int Fecha::diasEnMes(int month, int year) const {
    switch(month) {
        case 1: return 31;
        case 2: return esBisiesto(year) ? 29 : 28;
        case 3: return 31;
        case 4: return 30;
        case 5: return 31;
        case 6: return 30;
        case 7: return 31;
        case 8: return 31;
        case 9: return 30;
        case 10: return 31;
        case 11: return 30;
        case 12: return 31;
        default: return 31; // Por defecto 31
    }
}

// Constructor
Fecha::Fecha(int d, int m, int a) {
    setFecha(d, m, a);
}

// Constructor de copia
Fecha::Fecha(const Fecha &f) {
    dia = f.dia;
    mes = f.mes;
    anio = f.anio;
}

// M�todos setters
void Fecha::setFecha(int d, int m, int a) {
    // Ajustar mes
    if (m < 1) m = 1;
    if (m > 12) m = 12;
    mes = m;

    // Ajustar d�a
    if (d < 1) d = 1;
    int maxDias = diasEnMes(mes, a);
    if (d > maxDias) d = maxDias;
    dia = d;

    anio = a;
}

// M�todos getters
int Fecha::getDia() const { return dia; }
int Fecha::getMes() const { return mes; }
int Fecha::getAnio() const { return anio; }

// M�todo para verificar si el a�o es bisiesto
bool Fecha::bisiesto() const {
    return esBisiesto(anio);
}

// M�todo para mostrar la fecha en formato dd/mm/aaaa
void Fecha::ver() const {
    std::cout << (dia < 10 ? "0" : "") << dia << "/"
              << (mes < 10 ? "0" : "") << mes << "/" << anio;
}

// Sobrecarga de operadores
Fecha& Fecha::operator++() {
    dia++;
    int maxDias = diasEnMes(mes, anio);
    if (dia > maxDias) {
        dia = 1;
        mes++;
        if (mes > 12) {
            mes = 1;
            anio++;
        }
    }
    return *this;
}

Fecha Fecha::operator++(int) {
    Fecha temp(*this);
    ++(*this);
    return temp;
}

// Sobrecarga del operador + para sumar d�as
Fecha operator+(const Fecha& f, int days) {
    Fecha result(f);
    if (days < 0) {
        // Manejar d�as negativos
        while (days < 0) {
            result.dia--;
            if (result.dia < 1) {
                result.mes--;
                if (result.mes < 1) {
                    result.mes = 12;
                    result.anio--;
                }
                result.dia = result.diasEnMes(result.mes, result.anio);
            }
            days++;
        }
    }
    else {
        // Manejar d�as positivos
        result.dia += days;
        while (result.dia > result.diasEnMes(result.mes, result.anio)) {
            result.dia -= result.diasEnMes(result.mes, result.anio);
            result.mes++;
            if (result.mes > 12) {
                result.mes = 1;
                result.anio++;
            }
        }
    }
    return result;
}

Fecha operator+(int days, const Fecha& f) {
    return f + days;
}

// Operador de asignaci�n
Fecha& Fecha::operator=(const Fecha& f) {
    if (this != &f) {
        dia = f.dia;
        mes = f.mes;
        anio = f.anio;
    }
    return *this;
}

// Sobrecarga del operador << para imprimir la fecha en formato dd mmm aaaa
std::ostream& operator<<(std::ostream& os, const Fecha& f) {
    // Definir abreviaturas de meses
    const char* meses[] = {"ene", "feb", "mar", "abr", "may", "jun",
                           "jul", "ago", "sep", "oct", "nov", "dic"};
    os << (f.dia < 10 ? "0" : "") << f.dia << " "
       << meses[f.mes - 1] << " "
       << f.anio;
    return os;
}
