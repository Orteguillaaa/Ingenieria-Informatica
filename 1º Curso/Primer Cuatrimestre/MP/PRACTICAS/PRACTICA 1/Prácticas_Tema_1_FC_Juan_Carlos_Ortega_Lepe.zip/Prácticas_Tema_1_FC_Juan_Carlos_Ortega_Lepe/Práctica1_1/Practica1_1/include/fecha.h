#ifndef FECHA_H
#define FECHA_H

#include <iostream>

class Fecha {
private:
    int dia;
    int mes;
    int anio;

    // Verificamos si un a�o es bisiesto
    bool esBisiesto(int year) const;

    // Obtenemos el n�mero de d�as en un mes
    int diasEnMes(int month, int year) const;

public:
    // Constructor para el d�a, mes y a�o
    Fecha(int d, int m, int a);


    Fecha(const Fecha &f);

    // M�todos setters
    void setFecha(int d, int m, int a);

    // M�todos getters
    int getDia() const;
    int getMes() const;
    int getAnio() const;

    // M�todo para verificar si el a�o es bisiesto
    bool bisiesto() const;

    // M�todo para mostrar la fecha en formato dd/mm/aaaa
    void ver() const;

    Fecha& operator++();       // Prefijo
    Fecha operator++(int);     // Posfijo

    friend Fecha operator+(const Fecha& f, int days);
    friend Fecha operator+(int days, const Fecha& f);

    Fecha& operator=(const Fecha& f);

    // Imprimir la fecha en formato dd mmm aaaa
    friend std::ostream& operator<<(std::ostream& os, const Fecha& f);
};

#endif
