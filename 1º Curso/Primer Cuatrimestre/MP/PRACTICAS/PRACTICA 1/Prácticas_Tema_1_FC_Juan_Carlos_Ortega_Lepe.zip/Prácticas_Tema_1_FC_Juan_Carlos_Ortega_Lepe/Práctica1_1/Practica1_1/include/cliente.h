#ifndef CLIENTE_H
#define CLIENTE_H

#include "Fecha.h"
#include <iostream>
#include <cstring>

class Cliente {
private:
    long int dni;
    char *nombre;
    Fecha fechaAlta;

public:
    // Constructor
    Cliente(long int d, const char* n, Fecha f);


    Cliente(const Cliente& c);

    // Destructor
    ~Cliente();


    Cliente& operator=(const Cliente& c);

    // M�todos getters
    long int getDni() const;
    const char* getNombre() const;
    const Fecha& getFecha() const;

    // M�todos setters
    void setNombre(const char* n);
    void setFecha(const Fecha& f);

    bool operator==(const Cliente& c) const;

    // imprimir informaci�n del cliente
    friend std::ostream& operator<<(std::ostream& os, const Cliente& c);
};

#endif
