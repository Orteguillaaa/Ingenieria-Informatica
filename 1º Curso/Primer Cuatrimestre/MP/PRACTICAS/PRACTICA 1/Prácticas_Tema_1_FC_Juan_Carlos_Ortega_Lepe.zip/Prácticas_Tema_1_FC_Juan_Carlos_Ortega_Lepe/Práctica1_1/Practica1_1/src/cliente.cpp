#include "Cliente.h"

// Constructor
Cliente::Cliente(long int d, const char* n, Fecha f) : dni(d), fechaAlta(f) {
    if (n) {
        nombre = new char[strlen(n) + 1];
        strcpy(nombre, n);
    } else {
        nombre = new char[1];
        nombre[0] = '\0';
    }
}

// Constructor de copia
Cliente::Cliente(const Cliente& c) : dni(c.dni), fechaAlta(c.fechaAlta) {
    if (c.nombre) {
        nombre = new char[strlen(c.nombre) + 1];
        strcpy(nombre, c.nombre);
    } else {
        nombre = new char[1];
        nombre[0] = '\0';
    }
}

// Destructor
Cliente::~Cliente() {
    delete[] nombre;
}

// Operador de asignaci�n
Cliente& Cliente::operator=(const Cliente& c) {
    if (this != &c) {
        dni = c.dni;
        fechaAlta = c.fechaAlta;

        delete[] nombre;
        if (c.nombre) {
            nombre = new char[strlen(c.nombre) + 1];
            strcpy(nombre, c.nombre);
        } else {
            nombre = new char[1];
            nombre[0] = '\0';
        }
    }
    return *this;
}

// M�todos getters
long int Cliente::getDni() const {
    return dni;
}

const char* Cliente::getNombre() const {
    return nombre;
}

const Fecha& Cliente::getFecha() const {
    return fechaAlta;
}

// M�todos setters
void Cliente::setNombre(const char* n) {
    if (n) {
        delete[] nombre;
        nombre = new char[strlen(n) + 1];
        strcpy(nombre, n);
    }
}

void Cliente::setFecha(const Fecha& f) {
    fechaAlta = f;
}

// Sobrecarga del operador ==
bool Cliente::operator==(const Cliente& c) const {
    return dni == c.dni && strcmp(nombre, c.nombre) == 0 &&
           fechaAlta.getDia() == c.fechaAlta.getDia() &&
           fechaAlta.getMes() == c.fechaAlta.getMes() &&
           fechaAlta.getAnio() == c.fechaAlta.getAnio();
}

// Sobrecarga del operador << para imprimir informaci�n del cliente
std::ostream& operator<<(std::ostream& os, const Cliente& c) {
    os << c.nombre << " (" << c.dni << " � " << c.fechaAlta << ")";
    return os;
}
