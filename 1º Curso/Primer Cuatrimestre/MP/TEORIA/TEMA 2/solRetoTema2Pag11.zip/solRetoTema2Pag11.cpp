//PARA DEMOSTRAR EL CONSTRUCTOR, CONSTRUCTOR DE COPIA Y OPERADOR DE ASIGNACION QUE GENERA EL COMPILADOR
//VAMOS A A�ADIR MENSAJES POR PANTALLA EN LOS CONSTRUCTORES Y OPERATOR= PARA QUE SEPAMOS
//CUANDO SE ESTAN INVOCANDO Y ASI DEDUCIMOS LO QUE EL COMPILADOR HACE
#include <iostream>

using namespace std;

class Fecha {
  int dia, mes, anio;
public:
  Fecha() { cout << "Fecha()" << endl; }
  Fecha(const Fecha &f) { cout << "copia Fecha()" << endl; }
  Fecha &operator=(const Fecha &f) { cout << "Fecha::operator=()" << endl; return *this; }
};

class Base {
  int b;
public:
  Base() { cout << "Base()" << endl; }
  Base(const Base& obj) { cout << "copia Base()" << endl; }
  Base &operator=(const Base &b) { cout << "Base::operator=()" << endl; return *this; }
};

class Derivada:public Base {
  int x;
  Fecha f;
public:
//ESTOS SON LOS QUE GENERA EL COMPILADOR EN CASO DE QUE NOSOTROS NO LOS IMPLEMENTEMOS
//Derivada():Base(), f() { ; }
//Derivada(const Derivada& d):Base(d), x(d.x), f(d.f) { /*copia binaria*/ }
/*
  Derivada& operator=(const Derivada& d) {
    if (this!=&d) {
        Base::operator=(d);
        x=d.x;
        f=d.f;  //operator= de clase Fecha
    }
    return *this;
  }
*/
};

class Derivada2:public Base {
  int x;
  Fecha f;
public:
//COMO NO PONEMOS NADA EN ZONA INICIALIZADORES, EL COMPILADOR LO PONE POR NOSOTROS
  Derivada2() { cout << "Derivada2()" << endl; } //la linea 49 equivale a la linea 48
//Derivada2():Base(), f() { cout << "Derivada2()" << endl; }
  Derivada2(const Derivada2& obj) { cout << "copia Derivada2()" << endl; } //idem linea 51 y 50
//Derivada2(const Derivada2& obj):Base(), f() { cout << "copia Derivada2()" << endl; }

//EN EL OPERATOR= EL COMPILADOR NO A�ADE NADA MAS A LO QUE NOSOTROS CODIFICAMOS
  Derivada2& operator=(const Derivada2& obj) { cout << "Derivada2::operator=()" << endl; return *this; }
//Derivada2& operator=(const Derivada2& obj) { cout << "Derivada2::operator=()" << endl; return *this; }
};

int main() {
  cout << "-- 1 --\n";
  Fecha f1;
  Fecha f2(f1);
  f1=f2;
  cout << "-- 2 --\n";
  Base b1;
  Base b2(b1);
  b1=b2;
  cout << "-- 3 --\n";
  Derivada d1;
  cout << "-- 4 --\n";
  Derivada d2(d1);
  cout << "-- 5 --\n";
  d1=d2;
  cout << "-- 6 --\n";
  Derivada2 e1;
  cout << "-- 7 --\n";
  Derivada2 e2(e1);
  cout << "-- 8 --\n";
  e1=e2;
}
