#include <iostream>
#include <sstream>
#include <cstdlib> //system

using namespace std;

class Clase {
  int n;
//no hay punteros --> no hace falta destructor, constructor de copia y operator=
public:
  Clase(int x) { n=x; }
//EL CONSTRUCTOR DE COPIA Y OPERATOR= QUE GENERA EL COMPILADOR FUNCIONA BIEN YA
//QUE HACE COPIA BINARIA DE LOS DATOS Y AL NO HABER MEMORIA DINAMICA NO HAY PROBLEMA
};

class Clase2 {
  const int tamanio;
  int *tabladinamica; //el constructor crea la tabla con un tama�o fijo indicado por parametro
  Clase y;
//hay puntero --> hace falta destructor, constructor de copia y operator de asignacion
public:
  Clase2(int i);
  Clase2(int i, Clase c);
  ~Clase2() { delete [] tabladinamica; } //destructor (libera TODO lo que se crea con new en el constructor)
  Clase2(const Clase2 &c); //constructor de copia
  Clase2 &operator=(const Clase2 &c); //operador de asignacion
};

Clase2::Clase2(int i):tamanio(i), y(0) {
//tamanio=i; //ERROR los atributos constantes deben ir en zona inicializadores
  tabladinamica=new int[tamanio]; //creo tabladinamica con valores basura
//y=Clase(0); //ERROR los atributos objetos de otras clases deben ir en zona inicializadores
}

Clase2::Clase2(int i, Clase c):tamanio(i), y(c) {
//tamanio=i; //ERROR los atributos constantes deben ir en zona inicializadores
  tabladinamica=new int[tamanio]; //creo tabladinamica con valores basura
//y=c; //ERROR los atributos objetos de otras clases deben ir en zona inicializadores
}

Clase2::Clase2(const Clase2 &c):tamanio(c.tamanio), y(c.y) { //constructor de copia
  tabladinamica=new int[c.tamanio];
  for(int i=0; i<c.tamanio; i++) { //copia la informacion de la tabladinamica c a mi tabla dinamica
    tabladinamica[i]=c.tabladinamica[i];
  }
}

//COMO LA CLASE TIENE MEMORIA DINAMICA TAMBIEN SER�A CONVENIENTE HACER EL operator= (OPERADOR ASIGNACION)
//PERO NO SE IMPLEMENTA YA QUE NO TIENE SENTIDO DEBIDO A QUE Clase2 TIENE UN ATRIBUTO CONSTANTE tamanio
//QUE NO PUEDE MODIFICAR SU VALOR (POR TANTO EN EL MAIN NO TIENE SENTIDO USAR EL operator=)

//PONGO COMO SE HAR�A, COPIANDO TODOS LOS VALORES EXCEPTO tamanio QUE AL SER CONSTANTE NO SE PUEDE MODIFICAR
//EVIDENTEMENTE SI tamanio Y c.tamanio TIENE VALORES DIFERENTES EL CODIGO SIGUIENTE ESTA MAL EN EL SENTIDO
//DE QUE EL TAMA�O REAL DE LA TABLA tabladinamica Y tamanio NO SERIAN COHERENTES
Clase2 &Clase2::operator=(const Clase2 &c) {
  if (this!= &c) { //para evitar que si pongo a=a destruya parte del objeto a
    y=c.y;
    //tamanio=c.tamanio; //ERROR ES CONSTANTE Y NO SE PUEDE MODIFICAR
                         //COMO NO PUEDO MODIFICAR EL tamanio DE tabladinamica
                         //O BIEN NO HAGO NADA CON LA INFORMACION DE tabladinamica
                         //0 BIEN SOLO COPIO LOS DATOS DE c QUE PUEDA O QUEPA (HAGO ESTO ULTIMO)
    //delete [] tabladinamica;
    //tabladinamica=new int[tamanio];
    int t = tamanio<c.tamanio?tamanio:c.tamanio; //guardo en t el valor menor de tamanio y c.tamanio
    for(int i=0; i<t;  i++) {              //si tamanio<c.tamanio solo copia en tabladinamica los que quepa de c.tabladinamica
      tabladinamica[i]=c.tabladinamica[i]; //si tamanio>c.tamanio copia en tabladinamica todos los de c.tabladinamica
    }                                      //y en las celdas c.tamanio+1 hasta tamanio se conservar� la informaci�n original de tabladinamica
  }
  return *this; //DEVUELVO EL OBJETO UNA VEZ COPIADO
}

class Clase3: public Clase2 {
  static int n; //para saber cuantos objetos de tipo Clase3 se crean
  Clase z;
//aunque no hay punteros, debo hacer constructor copia y destructor para aumentar/disminuir la n
//EL DE COPIA QUE GENERA EL COMPILADOR HACE UNA COPIA BINARIA (HACE UN CLON) Y NO CAMBIA EL VALOR DE n
public:
  Clase3(int i, Clase c1, Clase c2);
  Clase3(const Clase3 &c); //constructor de copia
  ~Clase3() { n--; } //destructor: disminuye el contador n
  static int getn() { return n; }
};

int Clase3::n=0;

Clase3::Clase3(int i, Clase c1, Clase c2):Clase2(i, c1), z(c2) { //pasamos al padre(Clase2) lo que es suyo para que su constructor se encargue de lo suyo
  n++;  //incremento el atributo estatico n para llevar la cuenta de los objetos Clase3 que se crean
//z=c2; //ERROR los atributos objetos de otras clases deben ir en zona inicializadores
}

//EL C.COPIA DEL HIJO DEBE LLAMAR AL C.COPIA DEL PADRE PARA QUE
//SE ENCARGUE DE LO QUE ES DEL PADRE Y EL HIJO ENCARGARSE DE LO QUE ES DEL HIJO
Clase3::Clase3(const Clase3 &c):Clase2(c), z(c.z) {
  n++;
//z=c.z; //ERROR los atributos objetos de otras clases deben ir en zona inicializadores
}


//EL operator= (OPERADOR DE ASIGNACION) NO HAY QUE GENERARLO PORQUE Clase3 NO TIENE
//MEMORIA DINAMICA (lo tiene heredado del padre, pero de eso se encarga su padre)

//ESTE ES EL CONTRUCTOR DE COPIA QUE GENERA EL COMPILADOR
/*
Clase3::Clase3& operator=(const Clase3 &c) {
  if (this!=&c) { //para evitar que si pongo a=a destruya parte del objeto a
    Clase2::operator=(c); //PRIMERO LLAMA AL OPERATOR= DEL PADRE
    this->z=c.z;          //A CONTINUACION HACE UNA COPIA BINARIA DE LOS ATRIBUTOS EXCLUSIVOS DEL HIJO
  }
  return *this;
}
*/

//DE TODAS FORMAS SI EN EL PADRE NO GENERA OPERARATOR= POR TENER UN ATRIBUTO CONSTANTES, EN EL HIJO TAMPOCO LO GENERAR�A YA QUE Clase3 ES HIJA DE Clase2
//Y COMO CLASE2 TIENE UN ATRIBUTO tamanio CONSTANTE SE SUPONE QUE NO TIENE SENTIDO USARLO EN EL main()

int main() {
  Clase a(2), b(a);
  Clase2 x(2), y(3, a); //x con un atributo Clase de valor 0 y una tabla de 2 elementos
cout << "Hay " << Clase3::getn() << " objetos de Clase 3 creados" << endl;
  Clase3 h(2, a, b); //2 es el tama�o de la tabla din�mica, a es y, b es z
cout << "Hay " << Clase3::getn() << " objetos de Clase 3 creados" << endl;
  Clase3 hc(h); //SI NO HUBIERA HECHO EL CONTRUCTOR DE COPIA
                //NO DA ERROR AL COMPILAR PORQUE EL COMPILADOR GENERA UNO DE OFICIO
                //PERO EL QUE GENERA NO INCREMENTARIA EL CONTADOR DE OBJETOS n
cout << "Hay " << Clase3::getn() << " objetos de Clase 3 creados" << endl;
                //PRUEBE A QUITAR EL CONTRCUTOR DE COPIA EN Clase3
                //VER� QUE NO DA ERROR PERO CUENTA SOLO 1 OBJETO EN VEZ DE 2

  system("PAUSE");
  return EXIT_SUCCESS;
}
