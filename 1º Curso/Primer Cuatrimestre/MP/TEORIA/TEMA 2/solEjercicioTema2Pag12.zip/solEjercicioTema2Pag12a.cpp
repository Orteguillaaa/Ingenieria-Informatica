#include <iostream>
#include <cstring>
using namespace std;

class Fecha {
  int dia, mes, anio;
public:
  Fecha(int d, int m, int a) { dia=d; mes=m; anio=a; }
  int getDia() const { return dia; }
  int getMes() const { return mes; }
  int getAnio() const { return anio; }
};

class Persona {
  char *nombre;
  int edad;
public:
  Persona(char *n, int e) { nombre=new char[strlen(n)+1]; strcpy(nombre,n); edad=e; }
  Persona(const Persona &p) { nombre=new char[strlen(p.nombre)+1]; strcpy(nombre,p.nombre); edad=p.edad; }
  ~Persona() { delete [] nombre; }
  Persona &operator=(const Persona &p);
  const char *getNombre() const { return nombre; }
  int getEdad() const { return edad; }
};

Persona &Persona::operator=(const Persona &p) {
  if (this!=&p) {
    delete [] nombre;
    nombre=new char[strlen(p.nombre)+1];
    strcpy(nombre,p.nombre);
    edad=p.edad;
  }
  return *this;
}

class Trabajador: public Persona {
  const float sueldo;
  char *direccion;
  Fecha fechaAlta;
public:
  Trabajador(char *n, int e, float s, char *dir, Fecha f);
  Trabajador(const Trabajador &t);
  ~Trabajador();
  Trabajador &operator=(const Trabajador &t);
  bool operator==(const Trabajador &t) const;
  void ver() const;
  friend ostream& operator<<(ostream &s, const Trabajador &t);
};

Trabajador::Trabajador(char *n, int e, float s, char *dir, Fecha f)
:Persona(n,e), sueldo(s), fechaAlta(f) {
  direccion=new char[strlen(dir)+1];
  strcpy(direccion,dir);
}
Trabajador::Trabajador(const Trabajador &t)
:Persona(t), sueldo(t.sueldo), fechaAlta(t.fechaAlta) {
  direccion=new char[strlen(t.direccion)+1];
  strcpy(direccion, t.direccion);
}

Trabajador::~Trabajador() {
  delete [] direccion;
}

Trabajador& Trabajador::operator=(const Trabajador &t) {
  if (this!=&t) {
    Persona::operator=(t);
  //sueldo=t.sueldo; //es constante y no lo puedo modificar
    delete [] direccion;
    direccion=new char[strlen(t.direccion)+1];
    strcpy(direccion, t.direccion);
    fechaAlta=t.fechaAlta;
  }
  return *this;
}

bool Trabajador::operator==(const Trabajador &t) const {
  if (sueldo==t.sueldo && strcmp(direccion, t.direccion)==0
                       && fechaAlta.getDia()==t.fechaAlta.getDia()
                       && fechaAlta.getMes()==t.fechaAlta.getMes()
                       && fechaAlta.getAnio()==t.fechaAlta.getAnio()
                       && strcmp(getNombre(), t.getNombre())==0
                       && getEdad()==t.getEdad())
    return true;
  else
    return false;

}


void Trabajador::ver() const {
  cout << (*this) << endl; //como el operator<< lo tengo implementado lo aprovecho
//EQUIVALE A PONER LO SIGUIENTE
  operator<<(cout, *this); //LLAMO A LA FUNCION operator<<
  cout << endl;
}

ostream& operator<<(ostream &s, const Trabajador &t) {
  Fecha f=t.fechaAlta;
  s << t.getNombre() << ", " << t.getEdad() << ", " <<
       t.sueldo << ", " << t.direccion << ", " <<
     //t.fechaAlta.getDia() << "/" << t.fechaAlta.getMes() << "/" << t.fechaAlta.getAnio();
       f.getDia() << "/" << f.getMes() << "/" << f.getAnio();
  return s;
}

int main() {
  Fecha f(2,2,2000);
  Trabajador t("Pepe", 15, 1500.67, "Calle Rio 7",f);
  cout << t << endl;
  cout << "-----\n";
  t.ver();
}
