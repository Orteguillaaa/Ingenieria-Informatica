//SI AL CREAR UNA CLASE DEFINIMOS UN CONSTRUCTOR (con o sin par�metros), EL COMPILADOR SOLO CREA
//EL CONSTRUCTOR DE COPIA, que hace una copia binaria de los datos.

//MIRANDO LOS ERROES QUE DA EL COMPILADOR PODEMOS DEDUCIR QUE CONSTRUCTORES CREA Y CUALES NO
#include <iostream>

using namespace std;

class Punto {
  int x, y;
public:
  Punto(int x, int y) { this->x=x; this->y=y; } //hay constructor: el compilador crea el de copia
  void set(int a, int b) { x=a; y=b; }          //                 pero no crea el de oficio
};

class Linea {
  Punto x, y; //al ser objetos de otra clase, hay que llamarlo en la zona de inicializadores del constructor Linea
              //si se nos olvida, el compilador llama a su constructor sin parametros
public:
  Linea(int a, int b, int c, int d); //como definimos un constructor, no crea el de oficio
};                                   //pero si crea el constructor de copia

//ERROR EN LINEA 26 (NO SE HA LLAMADO AL CONSTRUCTOR DE LOS atributos OBJETOS x,y EN INICIALIZADORES)
//EL COMPILADOR LLAMA AL CONSTRUCTOR SIN PARAMETROS PARA CREAR x,y Y COMO EN Punto NO HAY Y EL COMPILADOR
//NO LO GENERA AL HABER CREADO NOSOTROS ALGUNO SE PRODUCE EL ERROR
Linea::Linea(int a, int b, int c, int d) { // Linea::Linea(int a, int b, int c, int d): x(), y() {
  x.set(a,b);
  y.set(c,d);
}
//ESTE ES EL DEBEMOS HACER PARA QUE NO DE ERROR
/*
Linea::Linea(int a, int b, int c, int d): x(a,b), y(c,d) {
  //x.set(a,b);
  //y.set(c,d);
}
*/

int main(int argc, char *argv[]) {
  Punto p1; //ERROR LINEA 39 no existe un contructor de oficio Punto() porque el compilador no lo genera al haber uno
  Punto p2(p1); //EJECUTA EL CONSTRUCTOR DE COPIA Punto(const &Punto p) QUE GENERA EL COMPILADOR
  Linea a(1,1,4,5); //ERROR AL EJECUTAR EL CONSTRUCTOR QUE HEMOS PROGRAMADO EN clase Linea
  Linea b(a); //EJECUTA EL CONSTRUCTOR DE COPIA Linea(const &Linea l) QUE GENERA EL COMPILADOR
  cout << "si aparece este mensaje es que ha podido crear los objetos p1, p2, a y b " << endl;
  system("PAUSE"); return EXIT_SUCCESS;
}



