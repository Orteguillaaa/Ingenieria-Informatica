//SI AL CREAR UNA CLASE NO DEFINIMOS NINGUN CONSTRUCTOR, EL COMPILADOR CREA UNO DE OFICIO (sin par�metros)
//QUE NO HACE NADA Y CREA EL CONSTRUCTOR DE COPIA, que hace una copia binaria de los datos.

//SI NO HAY ERRORES ES QUE EL COMPILADOR HA CREADO EN Punto EL CONSTRUCTOR DE OFICIO Y EL DE COPIA
#include <iostream>

using namespace std;

class Punto {
  int x, y;
public:
  //no hay constructor: el compilador crea el de oficio y el de copia
  void set(int a, int b) { x=a; y=b; }
};

class Linea {
  Punto x, y; //al ser objetos de otra clase, hay que llamarlo en la zona de inicializadores del constructor Linea
              //si se nos olvida, el compilador llama a su constructor sin parametros
public:
  Linea(int a, int b, int c, int d); //como definimos un constructor, no crea el de oficio
};                                   //pero si crea el constructor de copia

Linea::Linea(int a, int b, int c, int d) { // Linea::Linea(int a, int b, int c, int d): x(), y() {
  x.set(a,b);
  y.set(c,d);
}

int main(int argc, char *argv[]) {
  Punto p1; //EJECUTA EL CONSTRUCTOR DE OFICIO Punto() QUE GENERA EL COMPILADOR
  Punto p2(p1); //EJECUTA EL CONSTRUCTOR DE COPIA Punto(const &Punto p) QUE GENERA EL COMPILADOR
  Linea a(1,1,4,5); //EJECUTA EL CONSTRUCTOR QUE HEMOS PROGRAMADO EN clase Linea
  Linea b(a); //EJECUTA EL CONSTRUCTOR DE COPIA Linea(const &Linea l) QUE GENERA EL COMPILADOR
  cout << "si aparece este mensaje es que ha podido crear los objetos p1, p2, a y b " << endl;
  system("PAUSE"); return EXIT_SUCCESS;
}



