//SI CREAMOS EL CONSTRUCTOR DE COPIA, EL COMPILADOR NO CREA NINGUNO
//(NO CREA EL DE OFICIO PORQUE YA HAY UN CONSTRUCTOR Y NO CREA EL DE COPIA PORQUE NOSOTROS LO CREAMOS)

//MIRANDO LOS ERROES QUE DA EL COMPILADOR PODEMOS DEDUCIR QUE CONSTRUCTORES CREA Y CUALES NO
#include <iostream>

using namespace std;

class Punto {
  int x, y;
public:
  Punto(const Punto &p) { x=p.x; y=p.y; } //hay constructor de copia: el compilador no crea ninguno
  void set(int a, int b) { x=a; y=b; }
};

class Linea {
  Punto x, y; //al ser objetos de otra clase, hay que llamarlo en la zona de inicializadores del constructor Linea
              //si se nos olvida, el compilador llama a su constructor sin parametros
public:
  Linea(int a, int b, int c, int d); //como definimos un constructor, no crea el de oficio
};                                   //pero si crea el constructor de copia

//ERROR EN LINEA 26 (NO SE HA LLAMADO AL CONSTRUCTOR DE LOS atributos OBJETOS x,y EN INICIALIZADORES)
//EL COMPILADOR LLAMA AL CONSTRUCTOR SIN PARAMETROS PARA CREAR x,y Y COMO EN Punto NO HAY Y EL COMPILADOR
//NO LO GENERA AL HABER CREADO NOSOTROS ALGUNO SE PRODUCE EL ERROR
Linea::Linea(int a, int b, int c, int d) { // Linea::Linea(int a, int b, int c, int d): x(), y() {
  x.set(a,b);
  y.set(c,d);
}
//ESTE TAMBIEN DA ERROR. PARA QUE NO DE ERROR NECESITAMOS CREAR UN CONSTRUCTOR CON 2 PARAMETROS EN PUNTO
/*
Linea::Linea(int a, int b, int c, int d): x(a,b), y(c,d) {
  //x.set(a,b);
  //y.set(c,d);
}
*/

int main(int argc, char *argv[]) {
  Punto p1; //ERROR LINEA 39 no existe un contructor de oficio Punto() porque el compilador no lo genera al haber uno
  Punto p2(p1); //EJECUTA EL CONSTRUCTOR DE COPIA Punto(const &Punto p) QUE HEMOS HECHO
  Linea a(1,1,4,5); //ERROR AL EJECUTAR EL CONSTRUCTOR QUE HEMOS PROGRAMADO EN clase Linea
  Linea b(a); //EJECUTA EL CONSTRUCTOR DE COPIA Linea(const &Linea l) QUE GENERA EL COMPILADOR
  cout << "si aparece este mensaje es que ha podido crear los objetos p1, p2, a y b " << endl;
  system("PAUSE"); return EXIT_SUCCESS;
}



