#ifndef CADENA_H
#define CADENA_H

#include <iostream>
#include <cstring>
using namespace std;

class Cadena {
  char *cad;
public:
  Cadena() { cad=new char[1]; strcpy(cad,""); }                                     // a)
  Cadena(const char *c) { cad=new char[strlen(c)+1]; strcpy(cad,c); }               // b)
  Cadena(const Cadena &c) { cad=new char[strlen(c.cad)+1]; strcpy(cad,c.cad); }     // c)
  virtual  ~Cadena() { delete [] cad; }                                             // d)

  const char* c_str() const { return cad; }                                         // e)

  Cadena& operator=(const char *c) {                                                // f)
    delete [] cad; cad=new char[strlen(c)+1]; strcpy(cad,c);
    return *this;
  }

  Cadena& operator=(const Cadena &c) {                                              // g
    if (this!=&c) {
      delete [] cad; cad=new char[strlen(c.cad)+1]; strcpy(cad,c.cad);
    }
    return *this;
  }

  Cadena& operator+=(const char *c) {                                               // h)
    char *aux=cad;
    cad=new char[strlen(cad)+strlen(c)+1];
    strcpy(cad,aux); strcat(cad,c);
    delete [] aux;
    return *this;
  }

  Cadena& operator+=(const Cadena &c) {                                             // i)
    return operator+=(c.cad); // llama a h)
  }

  Cadena operator+(const char *c) const {                                           // j)
    char *aux=new char[strlen(cad)+strlen(c)+1];
    strcpy(aux,cad); strcat(aux,c);
    Cadena local(aux);
    delete [] aux;
    return local;
  }

  Cadena operator+(const Cadena &c) const {                                         // k)
    return operator+(c.cad); //llama a j)
  }

  bool operator==(const char *c) const { return strcmp(cad,c)==0; }                 // n


  bool operator==(const Cadena &c) const {  return strcmp(cad,c.cad)==0; }          // o)

};

Cadena operator+(const char *s, const Cadena &c) {                                  // m)
  return Cadena(s)+c; //llama a k)
}

bool operator==(const char *s, const Cadena &c) {                                   // p)
  return strcmp(s, c.c_str())==0;
}

ostream &operator<<(ostream &s, const Cadena &c) {                                  // q)
  s << c.c_str();
  return s;
}

istream &operator>>(istream &s, Cadena &c) {                                        // r)
  char aux[200];
  s >> aux;
  c=aux; //llama a f)
  return s;
}

istream& getline(istream& is, Cadena& c, char delim='\n') {                         // s)
  char aux[200];
  is.getline(aux, 200, delim);
  c=aux; //llama a f)
  return is;
}

#endif // CADENA_H
