#include <iostream>
#include <cstring>
#include "cadena.h"

using namespace std;

int main() {
  Cadena c1="Ana", c3=" Lopez", c4=c1, c5;
  const Cadena c2=" Maria";
  cout << c1 << c2 << " Perez" << c3 << endl;
  if (c5=="" && c1=="Ana" && "Ana"==c1 && c1==c4)
    cout << "c5 esta en blanco, c1 y c4 son iguales: " << c4 << endl;
  c1=c1;
  c5=c3;
  if (c5==c3)
    cout << "'" << c5 << "' igual a '" << c3.c_str() << "'\n";
  if (!(c2==c1))
    cout << "'" << c2.c_str() << "' distinto a '" << c3 << "'\n";
  cout << c1 << c5 << c3 << endl;
  c3=" Molina";
  cout << c1.c_str() << c5 << c3.c_str() << endl;
  c1="Jose";
  c1=c1+c2+" Roldan"+c3;
  cout << c1 << " termina en" << c3.c_str() << endl;
  c5="Pedro" + c5 + " Marquez";
  cout << c5 << endl;
  cout << "Indica 2 palabras: ";
  cin >> c1 >> c5;
  cout << "Las palabras son: \n";
  cout << c1 << endl << c5 << endl;
  cout << "Introduce 2 nombres compuestos: " << endl;
  cin.ignore(); getline(cin,c1);  getline(cin, c5);
  cout << "Los nombres introducidos son: \n";
  cout << c1 << endl << c5 << endl;
  cout << c1 << " tiene " << strlen(c1.c_str()) << " caracteres" << endl;

  c1=c3=c4="luis perez";
  cout << c1 << " - " << c3 << " - " << c4 << endl;
  c3="juan";
  cout << c1 << " - " << c3 << " - " << c4 << endl;

  system("PAUSE");
  return 0;
}
