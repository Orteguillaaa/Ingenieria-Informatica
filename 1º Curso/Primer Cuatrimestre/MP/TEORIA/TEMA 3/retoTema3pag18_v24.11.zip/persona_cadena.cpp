#include <iostream>
#include <cstring>
#include "Cadena.h"

using namespace std;

class Persona {
  Cadena nombre;
  const int edad; //la edad no se puede modificar
public:
  Persona(Cadena nom, int e);
//Persona(const Persona& p); //NO NECESARIO
//virtual ~Persona(); //NO NECESARIO
  Persona& operator=(const Persona& p);
  int getEdad() const { return this->edad; }
  Cadena getNombre() const { return this->nombre; }
  void setNombre(Cadena nom);
  bool operator==(Persona p) const;
};

Persona::Persona(Cadena nom, int e): edad(e) { this->nombre=nom;
  //this->edad=e; //ERROR edad es constante
}

/* Persona::~Persona() { //NO HAY QUE HACER NADA }
Persona::Persona( const Persona& p): edad(p.edad) {
  this->nombre=p.nombre;
}
*/

//necesario porque edad no puede cambiar
Persona& Persona::operator=(const Persona& p) {
  if (this != &p) {
    this->nombre=p.nombre;
  }
  return *this;
}

void Persona::setNombre(Cadena n) {
  this->nombre=n;
}

bool Persona::operator==(Persona p) const {
  return (this->edad==p.edad && this->nombre==p.nombre);
}

ostream& operator<<(ostream &s, const Persona &p) {
  s << p.getNombre() << " (" << p.getEdad() << ")";
  return s;
}

int main() {
  const Persona p1("pepe", 23);
  Persona p2("pepe", 23);
  Persona p3("pepe", 35);
  const Persona p4("maria", 25);
  if (p1==p2)
    cout << "p1 y p2 son iguales" << endl;
  cout << p1 << endl << p2 << endl
       << p3 << endl << p4 << endl;
  cout << p4.getNombre() << " tiene " << p4.getEdad() << " anios\n";
  p2.setNombre("ana");
  if (p1==p2)
    cout << "p1 y p2 son iguales" << endl;
  else
    cout << "p1 y p2 son distintos" << endl;
  p3=p4;
  cout << p1 << endl << p2 << endl
       << p3 << endl << p4 << endl;
  system("PAUSE");
  return 0;
}
