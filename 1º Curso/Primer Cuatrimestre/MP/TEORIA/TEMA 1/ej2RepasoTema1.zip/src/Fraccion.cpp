#include "Fraccion.h"

Fraccion::Fraccion(int numerador, int denominador) {
  this->numerador=numerador;
  this->denominador=denominador;
}

void Fraccion::set(int n, int d) {
  numerador=n;
  denominador=d;
}

bool Fraccion::operator>(Fraccion f) const {
  return (numerador*f.denominador>denominador*f.numerador);
};

Fraccion Fraccion::operator-() const {
  return Fraccion(-numerador, denominador);
}

Fraccion::operator int() const {
  int i=numerador/denominador;
  float f=(float)numerador/denominador;
  if (f-i>=0.5)
    i++;
  return i;
}

Fraccion & operator+=(Fraccion &f1, const Fraccion &f2) {
  f1.set(f1.getn()*f2.getd()+f2.getn()*f1.getd(), f1.getd()*f2.getd());
  return f1;
}

ostream& operator<<(ostream &s, const Fraccion &f) {
 if (f.getd()>0)
   s << f.getn() << "/" << f.getd();
 else //s act�a a modo de cout
   s << -f.getn() << "/" << -f.getd();
 return s;
}
