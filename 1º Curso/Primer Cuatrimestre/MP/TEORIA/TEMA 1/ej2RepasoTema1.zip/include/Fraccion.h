#ifndef FRACCION_H
#define FRACCION_H

#include <iostream>

using namespace std;

class Fraccion {
  int numerador, denominador;
public:
 Fraccion(int numerador=0, int denominador=1);
 virtual ~Fraccion() { }
 int getn() const { return numerador; }    //necesarios para la funcion operator+=
 int getd() const { return denominador; }  //necesarios para la funcion operator+=
 void set(int n=0, int d=1);               //necesarios para la funcion operator+=
 bool operator>(Fraccion f) const;
 Fraccion operator-() const;
 operator int() const;
 operator float() const {  return (float)numerador/denominador;  }
};

Fraccion & operator+=(Fraccion &f1, const Fraccion &f2);
ostream& operator<<(ostream &s, const Fraccion &f);

#endif // FRACCION_H
