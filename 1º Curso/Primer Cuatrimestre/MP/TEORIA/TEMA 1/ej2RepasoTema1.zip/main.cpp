#include <iostream>
#include "Fraccion.h"

using namespace std;

int main() {
 Fraccion a, b(5);
 const Fraccion c(7,4), d(b), e(5,-4);
 cout << "El numerador de c vale " << c.getn() << endl;
 if (d>a)
   a=-c;
 b+=e;
 cout << a << endl << b << endl << c << endl << d << endl << e << endl;
 cout << "el entero mas cercano a la fraccion " << c << " es " << (int)c << endl;
 cout << "el entero mas cercano a la fraccion " << e << " es " << (int)e << endl;
 cout << c << " = " << (float)c << endl;
 cout << e << " = " << (float)e << endl;
 system("PAUSE");
}
