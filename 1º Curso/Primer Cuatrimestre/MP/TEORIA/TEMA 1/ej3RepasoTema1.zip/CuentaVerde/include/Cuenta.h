#ifndef CUENTA_H
#define CUENTA_H

#include "Fecha.h"

class Cuenta {
  const long int numCuenta;
  long int dni;
  char *nombre;
  Fecha fechaAlta;
  static float tipoInteres;
  static long int contador;
  static const long int numCuentaInicial;
  static const float tipoInteresMaximo;
public:
  Cuenta(long int d, char *nom, Fecha f);
  virtual ~Cuenta();
  Cuenta(const Cuenta& c);
//Cuenta& operator=(const Cuenta& c);

  long int getNumCuenta() const { return numCuenta; }
  long int getDni() const { return dni; }
  const char *getNombre() const { return nombre; } //acordaros de poner const al inicio
  Fecha getFechaAlta() const { return fechaAlta; }
  static float getTipoInteres() { return tipoInteres; }
  static long int getContador() { return contador; }
  static long int getNumCuentaInicial() { return numCuentaInicial; }
  static float getTipoInteresMaximo() { return tipoInteresMaximo; }

  void setDni(long int dni) { this->dni=dni; }
  void setNombre(char *nombre);
  void setFechaAlta(Fecha f) { fechaAlta=f; }
  static void setTipoInteres(float tipo);

  friend ostream & operator<<(ostream &s, Cuenta c);
};

ostream & operator<<(ostream &s, Cuenta c);

#endif // CUENTA_H
