#include <iostream> //cout, cin
#include <cstring> //strlen, strcpy
#include "Cuenta.h"

using namespace std;

float Cuenta::tipoInteres=0.01;
long int Cuenta::contador=0;
const long int Cuenta::numCuentaInicial=84934400;
const float Cuenta::tipoInteresMaximo=0.05;
                                                                 //fechaAlta(f.getDia(), f.getMes(), f.getAnio()
Cuenta::Cuenta(long int d, char *nom, Fecha f):numCuenta(numCuentaInicial+contador),fechaAlta(f) {
  dni=d;
  nombre=new char[strlen(nom)+1];
  strcpy(nombre, nom);
  contador++;
}

Cuenta::~Cuenta() {
  delete [] nombre;
}

Cuenta::Cuenta(const Cuenta& c):numCuenta(c.numCuenta), fechaAlta(c.fechaAlta) {
  dni=c.dni;
  nombre=new char[strlen(c.nombre)+1];
  strcpy(nombre, c.nombre);
}

void Cuenta::setNombre(char *nombre) {
  delete [] this->nombre;
  this->nombre=new char[strlen(nombre)+1];
  strcpy(this->nombre, nombre);
}

void Cuenta::setTipoInteres(float tipo) {
  if (tipo>tipoInteresMaximo)
    tipo=tipoInteresMaximo;
  tipoInteres=tipo;
}


ostream & operator<<(ostream &s, Cuenta c) {
  s << c.numCuenta << " (" << c.tipoInteres*100 << "%) - " << c.nombre << " (" << c.dni << ") "
    << c.fechaAlta.getDia() << "/" << c.fechaAlta.getMes() << "/" << c.fechaAlta.getAnio();
  return s;
}

/*
ostream & operator<<(ostream &s, Cuenta c) {
  s << c.numCuenta << " (" << c.tipoInteres*100 << "%) - " << c.nombre << " (" << c.dni << ") "
    << c.fechaAlta;
  return s;
}
*/
