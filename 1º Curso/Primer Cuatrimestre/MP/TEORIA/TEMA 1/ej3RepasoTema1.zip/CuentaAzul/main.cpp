#include <iostream>
#include "Cuenta.h"
#include "Fecha.h"

using namespace std;

int main() {
    cout << "Hay creadas " << Cuenta::getContador() << " cuentas" << endl;
    cout << "tipo de interes por defecto: " << Cuenta::getTipoInteres() << endl;
    Fecha f1(2,3,2024), f2(5,10,2024), f3(f2);
//  cout << f1 << endl << f2 << endl << f3 << endl;
    cout << "-----------\n\n";
    Cuenta a(123456, "Pepe", f1);
    Cuenta b(126768, "Juanito", f2);
    Cuenta c(b);

    cout << "Hay creadas " << Cuenta::getContador() << " cuentas" << endl;
    cout << a << endl << b << endl << c << endl;
    a=b;

    cout << "Hay creadas " << Cuenta::getContador() << " cuentas" << endl;
    Cuenta::setTipoInteres(0.035);
    a.setDni(987654);
    b.setNombre("Luis");
    b.setFechaAlta(Fecha(1,1,2000));
    a.setFechaAlta(f2);
    cout << a.getNumCuenta() << endl << b.getNumCuenta() << endl;

    cout << a << endl << b << endl << c << endl;
    cout << "Hay creadas " << Cuenta::getContador() << " cuentas" << endl;
    return 0;
}
