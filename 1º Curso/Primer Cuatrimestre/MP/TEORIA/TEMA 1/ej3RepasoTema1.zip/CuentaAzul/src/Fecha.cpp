#include "Fecha.h"


/*
void Fecha::set(int d, int m, int a) {
  dia=d;
  mes=m;
  anio=a;
}

ostream & operator<<(ostream &s,  Fecha f) {
  s << f.getDia() << "/" << f.getMes() << "/" << f.getAnio();
  return s;
}
*/
