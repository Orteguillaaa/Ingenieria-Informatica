#ifndef FECHA_H
#define FECHA_H

#include <iostream>

using namespace std;

class Fecha {
  int dia, mes, anio;
public:
  Fecha(int d, int m, int a) {
   dia=d; mes=m; anio=a;
  }
//Fecha(const Fecha &f); //constructor de copia (LO GENERA EL COMPILADOR)
//Fecha& operator=(const Fecha &f); //operador de asignacion (LO GENERA EL COMPILADOR)
  int getDia() const { return dia; }
  int getMes() const { return mes; }
  int getAnio() const { return anio; }
  //void set(int d, int m, int a);
};

  //ostream & operator<<(ostream &s,  Fecha f);

#endif // FECHA_H
