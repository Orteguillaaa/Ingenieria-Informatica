.MODEL SMALL
.STACK 100h

.DATA
CADENA DB 5,0,0,0,0,0,0
PESO   DB 8,4,2,1
DEC_NAT DB ?
DEC_COMP DB ?
SIGNO DB ?                

MSG1 DB 13,10,'Introduce un n�mero binario de 4 bits: $'
MSG2 DB 13,10,'Binario natural (decimal): $'
MSG3 DB 13,10,'Complemento a 1 (decimal): $'

.CODE
    MOV AX, @DATA
    MOV DS, AX

    
    MOV AH, 09h
    LEA DX, MSG1
    INT 21h

   
    MOV AH, 0Ah
    LEA DX, CADENA
    INT 21h

    
    SUB CADENA[2], 48
    SUB CADENA[3], 48
    SUB CADENA[4], 48
    SUB CADENA[5], 48

    
    MOV AL, CADENA[2]
    CMP AL, 1
    JE ES_NEGATIVO

    MOV SIGNO, 0      
    JMP SEGUIR

ES_NEGATIVO:
    MOV SIGNO, 1      

SEGUIR:

    
    MOV AL, CADENA[2]
    MUL PESO[0]
    MOV DEC_NAT, AL

    MOV AL, CADENA[3]
    MUL PESO[1]
    ADD DEC_NAT, AL

    MOV AL, CADENA[4]
    MUL PESO[2]
    ADD DEC_NAT, AL

    MOV AL, CADENA[5]
    MUL PESO[3]
    ADD DEC_NAT, AL

   
    MOV AH, 09h
    LEA DX, MSG2
    INT 21h

   
    MOV AH, 0
    MOV BL, 10
    MOV AL, DEC_NAT
    DIV BL
    CMP AL, 0
    JE NAT_UNO
    PUSH AX
    MOV AH, 0
    MOV BL, 10
    DIV BL
    ADD AH, 48
    MOV DL, AH
    MOV AH, 02h
    INT 21h
    POP AX
NAT_UNO:
    ADD AH, 48
    MOV DL, AH
    MOV AH, 02h
    INT 21h

   
    CMP SIGNO, 1
    JNE NO_COMPLEMENTO_2
    MOV BL, CADENA[2]
    NOT BL
    AND BL, 1
    MOV CADENA[2], BL
NO_COMPLEMENTO_2:

    CMP SIGNO, 1
    JNE NO_COMPLEMENTO_3
    MOV BL, CADENA[3]
    NOT BL
    AND BL, 1
    MOV CADENA[3], BL
NO_COMPLEMENTO_3:

    CMP SIGNO, 1
    JNE NO_COMPLEMENTO_4
    MOV BL, CADENA[4]
    NOT BL
    AND BL, 1
    MOV CADENA[4], BL
NO_COMPLEMENTO_4:

    CMP SIGNO, 1
    JNE NO_COMPLEMENTO_5
    MOV BL, CADENA[5]
    NOT BL
    AND BL, 1
    MOV CADENA[5], BL
NO_COMPLEMENTO_5:

    
    MOV AL, CADENA[2]
    MUL PESO[0]
    MOV DEC_COMP, AL

    MOV AL, CADENA[3]
    MUL PESO[1]
    ADD DEC_COMP, AL

    MOV AL, CADENA[4]
    MUL PESO[2]
    ADD DEC_COMP, AL

    MOV AL, CADENA[5]
    MUL PESO[3]
    ADD DEC_COMP, AL

   
    MOV AH, 09h
    LEA DX, MSG3
    INT 21h

   
    CMP SIGNO, 1
    JNE NO_SIGNO

    MOV DL, '-'
    MOV AH, 02h
    INT 21h

NO_SIGNO:

   
    MOV AH, 0
    MOV BL, 10
    MOV AL, DEC_COMP
    DIV BL
    CMP AL, 0
    JE COMP_UNO
    PUSH AX
    MOV AH, 0
    MOV BL, 10
    DIV BL
    ADD AH, 48
    MOV DL, AH
    MOV AH, 02h
    INT 21h
    POP AX
COMP_UNO:
    ADD AH, 48
    MOV DL, AH
    MOV AH, 02h
    INT 21h

    
    MOV AH, 00h
    INT 16h

    
    MOV AH, 4Ch
    INT 21h

END